package src;

public interface Printable {
    void print();
}
