package main.java.com.interfaces;

public interface Screen{
    void screenQuality();
}