class Main{

public static void main (String [] args){
    Animal animal = new Lion("Simba", 100, 5);
    System.out.println(animal);
}


}