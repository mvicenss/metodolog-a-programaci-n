package main.java.com.interfaces;

public interface Ram{
    void ramCapacity();
}