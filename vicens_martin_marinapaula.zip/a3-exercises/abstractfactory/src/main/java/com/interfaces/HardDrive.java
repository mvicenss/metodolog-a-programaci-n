package abstractfactory.src.main.java.com.interfaces;

public interface HardDrive {
    void driveCapacity();
}
