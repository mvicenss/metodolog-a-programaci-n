package main.java.com.interfaces;

public interface HardDrive{
    void hardDriveCapacity();
}